// Configurações da aplicação
const APP_CONFIG = {
  API_URL: 'http://localhost:3001/api',
  STORAGE_KEYS: {
    TOKEN: 'auth_token',
    USER: 'user_data',
    REFRESH_TOKEN: 'refresh_token'
  }
};

// ========== GERENCIAMENTO DE AUTENTICAÇÃO ==========

class AuthManager {
  static isLoggedIn() {
    return !!localStorage.getItem(APP_CONFIG.STORAGE_KEYS.TOKEN);
  }

  static getToken() {
    return localStorage.getItem(APP_CONFIG.STORAGE_KEYS.TOKEN);
  }

  static getUser() {
    const user = localStorage.getItem(APP_CONFIG.STORAGE_KEYS.USER);
    return user ? JSON.parse(user) : null;
  }

  static async login(email, senha) {
    try {
      const response = await fetch(`${APP_CONFIG.API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, senha })
      });

      const data = await response.json();

      if (response.ok) {
        localStorage.setItem(APP_CONFIG.STORAGE_KEYS.TOKEN, data.token);
        localStorage.setItem(APP_CONFIG.STORAGE_KEYS.USER, JSON.stringify(data.usuario));
        return { success: true, usuario: data.usuario };
      } else {
        return { success: false, error: data.error };
      }
    } catch (err) {
      console.error('Erro ao fazer login:', err);
      return { success: false, error: 'Erro de conexão' };
    }
  }

  static logout() {
    localStorage.removeItem(APP_CONFIG.STORAGE_KEYS.TOKEN);
    localStorage.removeItem(APP_CONFIG.STORAGE_KEYS.USER);
    window.location.href = '/';
  }
}

// ========== API HELPER ==========

class API {
  static async request(endpoint, options = {}) {
    const url = `${APP_CONFIG.API_URL}${endpoint}`;
    const token = AuthManager.getToken();

    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers
      });

      const data = await response.json();

      if (response.status === 401) {
        AuthManager.logout();
        return { success: false, error: 'Não autorizado' };
      }

      return {
        success: response.ok,
        status: response.status,
        data
      };
    } catch (err) {
      console.error('Erro na requisição:', err);
      return { success: false, error: 'Erro de conexão' };
    }
  }

  static get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  }

  static post(endpoint, body) {
    return this.request(endpoint, { 
      method: 'POST', 
      body: JSON.stringify(body) 
    });
  }

  static put(endpoint, body) {
    return this.request(endpoint, { 
      method: 'PUT', 
      body: JSON.stringify(body) 
    });
  }

  static delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }
}

// ========== UI UTILITIES ==========

class UI {
  static showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.margin = '0 0 20px 0';
    alertDiv.role = 'alert';

    const container = document.querySelector('main') || document.body;
    container.insertBefore(alertDiv, container.firstChild);

    setTimeout(() => alertDiv.remove(), 5000);
  }

  static showSpinner() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner';
    spinner.id = 'loading-spinner';
    spinner.style.position = 'fixed';
    spinner.style.top = '50%';
    spinner.style.left = '50%';
    spinner.style.transform = 'translate(-50%, -50%)';
    spinner.style.zIndex = '9999';
    document.body.appendChild(spinner);
  }

  static hideSpinner() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) spinner.remove();
  }

  static formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  }

  static getStatusBadgeClass(status) {
    const statusMap = {
      'Novo': 'status-novo',
      'Em Atendimento': 'status-atendimento',
      'Aguardando Usuário': 'status-aguardando',
      'Resolvido': 'status-resolvido',
      'Fechado': 'status-fechado',
      'Cancelado': 'status-fechado'
    };
    return statusMap[status] || 'badge-secondary';
  }

  static getPriorityBadgeClass(prioridade) {
    const prioridadeMap = {
      'Crítico': 'priority-critico',
      'Alto': 'priority-alto',
      'Médio': 'priority-medio',
      'Baixa': 'priority-baixa',
      'Trivial': 'priority-trivial'
    };
    return prioridadeMap[prioridade] || 'badge-secondary';
  }

  static createBadge(text, className) {
    return `<span class="badge ${className}">${text}</span>`;
  }
}

// ========== NAVEGAÇÃO ==========

function setupNavigation() {
  const user = AuthManager.getUser();
  if (!user) return;

  // Atualizar nome do usuário no header
  const userNameEl = document.querySelector('.user-name');
  if (userNameEl) {
    userNameEl.textContent = user.nome;
  }

  // Atualizar avatar
  const avatarEl = document.querySelector('.user-avatar');
  if (avatarEl) {
    avatarEl.textContent = user.nome.charAt(0).toUpperCase();
  }

  // Setup logout
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      if (confirm('Deseja fazer logout?')) {
        AuthManager.logout();
      }
    });
  }

  // Ativar menu item atual
  const currentPath = window.location.pathname;
  document.querySelectorAll('.sidebar-nav a').forEach(link => {
    const href = link.getAttribute('href');
    if (currentPath.includes(href)) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

// ========== PROTEÇÃO DE ROTAS ==========

function checkAuth() {
  const loginPage = new URL(window.location).pathname === '/';
  const isLoggedIn = AuthManager.isLoggedIn();

  if (!isLoggedIn && !loginPage) {
    window.location.href = '/';
  }

  if (isLoggedIn && loginPage) {
    const user = AuthManager.getUser();
    const redirectPath = user.funcao === 'Usuário Final' ? '/dashboard' : '/gerenciamento';
    window.location.href = redirectPath;
  }
}

// ========== INICIALIZAÇÃO ==========

document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  setupNavigation();
});

// Exportar para uso nos arquivos de página
window.AuthManager = AuthManager;
window.API = API;
window.UI = UI;
window.APP_CONFIG = APP_CONFIG;
