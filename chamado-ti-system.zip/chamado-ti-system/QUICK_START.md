# 🚀 Quick Start - Sistema de Chamados de TI

## Iniciar Rápido (5 minutos)

### 1️⃣ Clonar/Acessar Diretório

```bash
cd chamado-ti-system
```

### 2️⃣ Instalar Dependências

```bash
cd backend
npm install
```

### 3️⃣ Iniciar o Backend

```bash
npm start
```

Você verá:
```
╔════════════════════════════════════════╗
║   Sistema de Chamados de TI            ║
║   Backend iniciado                     ║
╚════════════════════════════════════════╝

📍 Servidor: http://localhost:3001
📍 API: http://localhost:3001/api
```

### 4️⃣ Abrir o Frontend

Em seu navegador, acesse:
```
http://localhost:3001
```

### 5️⃣ Fazer Login

Use uma das contas de teste:

**Usuário Final:**
- Email: `user@empresa.com`
- Senha: `123456`

**Técnico de TI:**
- Email: `tecnico@empresa.com`
- Senha: `123456`

**Gestor de TI:**
- Email: `gerente@empresa.com`
- Senha: `123456`

---

## 📁 Estrutura Básica

```
chamado-ti-system/
├── frontend/          # Interface web
│   ├── index.html     # Login
│   ├── dashboard.html # Dashboard
│   ├── novo-chamado.html
│   ├── meus-chamados.html
│   ├── gerenciamento.html (TI)
│   ├── relatorios.html (Gestor)
│   └── assets/
│       ├── css/style.css
│       └── js/app.js
│
└── backend/           # Server Node.js
    ├── server.js      # Entrada Principal
    ├── config/        # Configurações
    ├── routes/        # Rotas da API
    │   ├── auth.js    # Login
    │   ├── chamados.js
    │   ├── usuarios.js
    │   └── relatorios.js
    ├── middleware/    # Autenticação
    ├── data/db.json   # Banco de dados (JSON)
    └── package.json
```

---

## 🔑 Endpoints Principais

### Autenticação
- `POST /api/auth/login` - Fazer login
- `POST /api/auth/logout` - Logout

### Chamados
- `GET /api/chamados` - Listar chamados
- `POST /api/chamados` - Criar novo chamado
- `GET /api/chamados/:id` - Detalhes do chamado
- `PUT /api/chamados/:id` - Atualizar chamado

### Relatórios
- `GET /api/relatorios/dashboard` - Dashboard
- `GET /api/relatorios/sla` - Análise de SLA

---

## 💡 Recursos Disponíveis

✅ **Autenticação:** Login com JWT  
✅ **Criar Chamados:** Abertura intuitiva  
✅ **Dashboard:** KPIs em tempo real  
✅ **Acompanhamento:** Status e histórico  
✅ **Gerenciamento:** Fila para técnicos  
✅ **Relatórios:** Análise de performance  
✅ **Responsivo:** Funciona em mobile/desktop  

---

## 🔧 Troubleshooting

**Erro: "EADDRINUSE"** (Porta em uso)
```bash
# Use porta diferente
PORT=3002 npm start
```

**Erro: "Cannot find module"** (Dependências faltando)
```bash
npm install
```

**Banco de dados não encontra**
```bash
# Verifique se db.json existe em backend/data/
```

---

## 📚 Próximos Passos

1. **Explorar Interface:** Teste as funcionalidades como diferentes usuários
2. **Consultar Docs:** Leia `README.md` para documentação completa
3. **Customizar:** Edite `backend/config/constants.js` para suas categorias
4. **Integrar BD Real:** Migre de JSON Server para MongoDB/PostgreSQL
5. **Deploy:** Configure servidor para produção

---

## 🎯 Funcionalidades por Perfil

### 👤 Usuário Final
- ✅ Abrir chamados
- ✅ Acompanhar status
- ✅ Adicionar comentários
- ✅ Ver histórico

### 🔧 Técnico de TI
- ✅ Visualizar fila
- ✅ Assumir chamados
- ✅ Atualizar status
- ✅ Adicionar anotações internas

### 📊 Gestor de TI
- ✅ Dashboard gerencial
- ✅ Relatórios de performance
- ✅ Análise de SLA
- ✅ Criação de usuários

---

## 📞 Suporte

Para dúvidas, consulte:
- **README.md** - Documentação completa
- **Arquivos HTML** - Comentários inline
- **Arquivos JS** - Funções bem documentadas

---

**Versão:** 1.0.0  
**Última atualização:** 19/05/2026
