const express = require('express');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { verificarToken, verificarEquipeTI, validarChamado, validarStatus } = require('../middleware/auth');
const constants = require('../config/constants');

const router = express.Router();

// Carregar e salvar banco de dados
const dbPath = path.join(__dirname, '../data/db.json');
const getDB = () => JSON.parse(fs.readFileSync(dbPath, 'utf8'));
const saveDB = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

// Gerar ID único para chamado
const gerarIDChamado = () => {
  const db = getDB();
  const maxId = Math.max(0, ...db.chamados.map(c => {
    const match = c.id.match(/TI-2026-(\d+)/);
    return match ? parseInt(match[1]) : 0;
  }));
  return `TI-2026-${String(maxId + 1).padStart(5, '0')}`;
};

// GET /api/chamados - Listar chamados
router.get('/', verificarToken, (req, res) => {
  try {
    const db = getDB();
    let chamados = db.chamados;

    // Se for usuário final, mostrar apenas seus chamados
    if (req.usuario.funcao === 'Usuário Final') {
      chamados = chamados.filter(c => c.usuario_id === req.usuario.id);
    }

    // Filtros
    const { status, prioridade, categoria, ordenar } = req.query;

    if (status) {
      chamados = chamados.filter(c => c.status === status);
    }

    if (prioridade) {
      chamados = chamados.filter(c => c.prioridade === prioridade);
    }

    if (categoria) {
      chamados = chamados.filter(c => c.categoria === categoria);
    }

    // Ordenação
    if (ordenar === 'recente') {
      chamados.sort((a, b) => new Date(b.data_criacao) - new Date(a.data_criacao));
    } else if (ordenar === 'prioridade') {
      const prioridadeOrder = { 'Crítico': 0, 'Alto': 1, 'Médio': 2, 'Baixa': 3, 'Trivial': 4 };
      chamados.sort((a, b) => prioridadeOrder[a.prioridade] - prioridadeOrder[b.prioridade]);
    } else if (ordenar === 'sla') {
      chamados.sort((a, b) => new Date(a.sla_expira) - new Date(b.sla_expira));
    }

    res.json({
      total: chamados.length,
      chamados
    });
  } catch (err) {
    console.error('Erro ao listar chamados:', err);
    res.status(500).json({ error: 'Erro ao listar chamados' });
  }
});

// GET /api/chamados/:id - Obter detalhes de um chamado
router.get('/:id', verificarToken, (req, res) => {
  try {
    const db = getDB();
    const chamado = db.chamados.find(c => c.id === req.params.id);

    if (!chamado) {
      return res.status(404).json({ error: 'Chamado não encontrado' });
    }

    // Verificar permissão
    if (req.usuario.funcao === 'Usuário Final' && chamado.usuario_id !== req.usuario.id) {
      return res.status(403).json({ error: 'Acesso negado' });
    }

    res.json(chamado);
  } catch (err) {
    console.error('Erro ao obter chamado:', err);
    res.status(500).json({ error: 'Erro ao obter chamado' });
  }
});

// POST /api/chamados - Criar novo chamado
router.post('/', verificarToken, validarChamado, (req, res) => {
  try {
    const { titulo, descricao, categoria, subcategoria, prioridade, anexos } = req.body;

    const chamado = {
      id: gerarIDChamado(),
      titulo,
      descricao,
      categoria,
      subcategoria: subcategoria || '',
      prioridade,
      status: 'Novo',
      usuario_id: req.usuario.id,
      tecnico_id: null,
      data_criacao: new Date().toISOString(),
      data_atualizacao: new Date().toISOString(),
      data_resolucao: null,
      sla_expira: new Date(Date.now() + constants.SLA[prioridade] * 3600000).toISOString(),
      anexos: anexos || [],
      comentarios: [{
        id: uuidv4(),
        usuario_id: req.usuario.id,
        nome: req.usuario.nome,
        texto: `Chamado criado por ${req.usuario.nome}`,
        tipo: 'sistema',
        data: new Date().toISOString()
      }]
    };

    const db = getDB();
    db.chamados.push(chamado);
    saveDB(db);

    res.status(201).json({
      success: true,
      message: 'Chamado criado com sucesso',
      chamado
    });
  } catch (err) {
    console.error('Erro ao criar chamado:', err);
    res.status(500).json({ error: 'Erro ao criar chamado' });
  }
});

// PUT /api/chamados/:id - Atualizar chamado
router.put('/:id', verificarToken, validarStatus, (req, res) => {
  try {
    const db = getDB();
    const chamado = db.chamados.find(c => c.id === req.params.id);

    if (!chamado) {
      return res.status(404).json({ error: 'Chamado não encontrado' });
    }

    // Verificar permissão
    if (req.usuario.funcao === 'Usuário Final' && chamado.usuario_id !== req.usuario.id) {
      return res.status(403).json({ error: 'Acesso negado' });
    }

    const { status, comentario, tipo_comentario, tecnico_id, prioridade } = req.body;

    if (status && constants.STATUS.includes(status)) {
      chamado.status = status;
      if (status === 'Resolvido' || status === 'Fechado') {
        chamado.data_resolucao = new Date().toISOString();
      }
    }

    if (prioridade && constants.PRIORIDADES.includes(prioridade)) {
      chamado.prioridade = prioridade;
      chamado.sla_expira = new Date(Date.now() + constants.SLA[prioridade] * 3600000).toISOString();
    }

    if (tecnico_id) {
      chamado.tecnico_id = tecnico_id;
    }

    if (comentario) {
      chamado.comentarios.push({
        id: uuidv4(),
        usuario_id: req.usuario.id,
        nome: req.usuario.nome,
        texto: comentario,
        tipo: tipo_comentario || 'publico',
        data: new Date().toISOString()
      });
    }

    chamado.data_atualizacao = new Date().toISOString();

    saveDB(db);

    res.json({
      success: true,
      message: 'Chamado atualizado com sucesso',
      chamado
    });
  } catch (err) {
    console.error('Erro ao atualizar chamado:', err);
    res.status(500).json({ error: 'Erro ao atualizar chamado' });
  }
});

// DELETE /api/chamados/:id - Deletar chamado
router.delete('/:id', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const index = db.chamados.findIndex(c => c.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ error: 'Chamado não encontrado' });
    }

    db.chamados.splice(index, 1);
    saveDB(db);

    res.json({
      success: true,
      message: 'Chamado deletado com sucesso'
    });
  } catch (err) {
    console.error('Erro ao deletar chamado:', err);
    res.status(500).json({ error: 'Erro ao deletar chamado' });
  }
});

// GET /api/chamados/meus - Meus chamados (para usuário logado)
router.get('/meus/chamados', verificarToken, (req, res) => {
  try {
    const db = getDB();
    let chamados = db.chamados.filter(c => c.usuario_id === req.usuario.id);

    // Ordenar por data de criação decrescente
    chamados.sort((a, b) => new Date(b.data_criacao) - new Date(a.data_criacao));

    res.json({
      total: chamados.length,
      chamados
    });
  } catch (err) {
    console.error('Erro ao listar meus chamados:', err);
    res.status(500).json({ error: 'Erro ao listar chamados' });
  }
});

module.exports = router;
