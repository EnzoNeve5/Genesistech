const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const constants = require('../config/constants');

const router = express.Router();

// Carregar banco de dados
const dbPath = path.join(__dirname, '../data/db.json');
const getDB = () => JSON.parse(fs.readFileSync(dbPath, 'utf8'));

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).json({ 
      error: 'Email e senha são obrigatórios' 
    });
  }

  try {
    const db = getDB();
    const usuario = db.usuarios.find(u => u.email === email);

    if (!usuario) {
      return res.status(401).json({ 
        error: 'Email ou senha incorretos' 
      });
    }

    // Verificar senha (simplificado - em produção usar bcrypt)
    // Para este exemplo, todas as senhas são '123456'
    if (senha !== '123456') {
      return res.status(401).json({ 
        error: 'Email ou senha incorretos' 
      });
    }

    if (!usuario.ativo) {
      return res.status(401).json({ 
        error: 'Usuário inativo' 
      });
    }

    // Gerar token JWT
    const token = jwt.sign(
      {
        id: usuario.id,
        email: usuario.email,
        nome: usuario.nome,
        funcao: usuario.funcao,
        departamento: usuario.departamento
      },
      constants.JWT_SECRET,
      { expiresIn: constants.JWT_EXPIRE }
    );

    res.json({
      success: true,
      message: 'Login realizado com sucesso',
      token,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        funcao: usuario.funcao,
        departamento: usuario.departamento
      }
    });
  } catch (err) {
    console.error('Erro ao fazer login:', err);
    res.status(500).json({ 
      error: 'Erro ao fazer login' 
    });
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  // No frontend, remover o token do localStorage
  res.json({
    success: true,
    message: 'Logout realizado com sucesso'
  });
});

// GET /api/auth/me
router.get('/me', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ 
      error: 'Token não fornecido' 
    });
  }

  try {
    const decoded = jwt.verify(token, constants.JWT_SECRET);
    res.json({
      usuario: decoded
    });
  } catch (err) {
    return res.status(401).json({ 
      error: 'Token inválido ou expirado' 
    });
  }
});

// POST /api/auth/validar-token
router.post('/validar-token', (req, res) => {
  const { token } = req.body;

  if (!token) {
    return res.status(400).json({ 
      error: 'Token não fornecido' 
    });
  }

  try {
    const decoded = jwt.verify(token, constants.JWT_SECRET);
    res.json({
      valido: true,
      usuario: decoded
    });
  } catch (err) {
    res.json({
      valido: false,
      error: 'Token inválido ou expirado'
    });
  }
});

module.exports = router;
