const express = require('express');
const fs = require('fs');
const path = require('path');
const { verificarToken, verificarEquipeTI } = require('../middleware/auth');
const constants = require('../config/constants');

const router = express.Router();

// Carregar banco de dados
const dbPath = path.join(__dirname, '../data/db.json');
const getDB = () => JSON.parse(fs.readFileSync(dbPath, 'utf8'));

// Função auxiliar para calcular estatísticas
const calcularEstatisticas = (chamados) => {
  const total = chamados.length;
  const novo = chamados.filter(c => c.status === 'Novo').length;
  const emAtendimento = chamados.filter(c => c.status === 'Em Atendimento').length;
  const resolvido = chamados.filter(c => c.status === 'Resolvido').length;
  const fechado = chamados.filter(c => c.status === 'Fechado').length;

  // Calcular tempo médio de resolução
  const chamadosResolvidos = chamados.filter(c => c.data_resolucao);
  const tempoMedioResolucao = chamadosResolvidos.length > 0
    ? chamadosResolvidos.reduce((acc, c) => {
        const inicio = new Date(c.data_criacao);
        const fim = new Date(c.data_resolucao);
        return acc + (fim - inicio) / 3600000; // em horas
      }, 0) / chamadosResolvidos.length
    : 0;

  // Contar chamados por prioridade
  const porPrioridade = {};
  constants.PRIORIDADES.forEach(p => {
    porPrioridade[p] = chamados.filter(c => c.prioridade === p).length;
  });

  return {
    total,
    novo,
    emAtendimento,
    resolvido,
    fechado,
    porPrioridade,
    tempoMedioResolucao: Math.round(tempoMedioResolucao * 100) / 100
  };
};

// GET /api/relatorios/dashboard - Dashboard gerencial
router.get('/dashboard', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const chamados = db.chamados;

    // Estatísticas gerais
    const stats = calcularEstatisticas(chamados);

    // Chamados por status
    const porStatus = {};
    constants.STATUS.forEach(s => {
      porStatus[s] = chamados.filter(c => c.status === s).length;
    });

    // Chamados por categoria
    const porCategoria = {};
    constants.CATEGORIAS.forEach(cat => {
      porCategoria[cat] = chamados.filter(c => c.categoria === cat).length;
    });

    // Técnicos mais produtivos
    const tecnicoStats = {};
    chamados.forEach(c => {
      if (c.tecnico_id) {
        if (!tecnicoStats[c.tecnico_id]) {
          tecnicoStats[c.tecnico_id] = {
            total: 0,
            resolvido: 0
          };
        }
        tecnicoStats[c.tecnico_id].total++;
        if (c.status === 'Resolvido' || c.status === 'Fechado') {
          tecnicoStats[c.tecnico_id].resolvido++;
        }
      }
    });

    // Enriquecer dados dos técnicos com nomes
    const tecnicoComNome = {};
    Object.entries(tecnicoStats).forEach(([id, stats]) => {
      const tecnico = db.usuarios.find(u => u.id === id);
      if (tecnico) {
        tecnicoComNome[tecnico.nome] = stats;
      }
    });

    // Chamados próximos do SLA
    const agora = new Date();
    const proximosSLA = chamados
      .filter(c => c.status !== 'Resolvido' && c.status !== 'Fechado')
      .map(c => ({
        id: c.id,
        titulo: c.titulo,
        sla_expira: c.sla_expira,
        horas_restantes: (new Date(c.sla_expira) - agora) / 3600000
      }))
      .filter(c => c.horas_restantes <= 4)
      .sort((a, b) => a.horas_restantes - b.horas_restantes);

    // Chamados com maior tempo
    const comMaiorTempo = chamados
      .filter(c => c.status !== 'Resolvido' && c.status !== 'Fechado')
      .map(c => ({
        id: c.id,
        titulo: c.titulo,
        categoria: c.categoria,
        prioridade: c.prioridade,
        horas_aberto: (agora - new Date(c.data_criacao)) / 3600000
      }))
      .sort((a, b) => b.horas_aberto - a.horas_aberto)
      .slice(0, 5);

    res.json({
      timestamp: new Date().toISOString(),
      resumo: stats,
      porStatus,
      porCategoria,
      produtividadeTecnico: tecnicoComNome,
      proximosSLA,
      comMaiorTempo
    });
  } catch (err) {
    console.error('Erro ao gerar dashboard:', err);
    res.status(500).json({ error: 'Erro ao gerar dashboard' });
  }
});

// GET /api/relatorios/sla - Relatório de SLA
router.get('/sla', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const chamados = db.chamados;

    const agora = new Date();
    const chamadosAbertos = chamados.filter(c => 
      c.status !== 'Resolvido' && c.status !== 'Fechado'
    );

    let comSLA = 0;
    let semSLA = 0;

    const detalhes = chamadosAbertos.map(c => {
      const slaExpira = new Date(c.sla_expira);
      const comSLAFina = slaExpira > agora;
      if (comSLAFina) comSLA++;
      else semSLA++;

      return {
        id: c.id,
        titulo: c.titulo,
        prioridade: c.prioridade,
        sla_expira: c.sla_expira,
        dentro_sla: comSLAFina,
        horas_restantes: (slaExpira - agora) / 3600000
      };
    });

    const taxa = chamadosAbertos.length > 0
      ? (comSLA / chamadosAbertos.length * 100).toFixed(2)
      : 100;

    res.json({
      timestamp: new Date().toISOString(),
      total_abertos: chamadosAbertos.length,
      dentro_sla: comSLA,
      fora_sla: semSLA,
      taxa_compliance: `${taxa}%`,
      detalhes: detalhes.sort((a, b) => a.horas_restantes - b.horas_restantes)
    });
  } catch (err) {
    console.error('Erro ao gerar relatório de SLA:', err);
    res.status(500).json({ error: 'Erro ao gerar relatório de SLA' });
  }
});

// GET /api/relatorios/por-categoria - Análise por categoria
router.get('/por-categoria', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const chamados = db.chamados;

    const analise = {};
    constants.CATEGORIAS.forEach(cat => {
      const chamadosCategoria = chamados.filter(c => c.categoria === cat);
      analise[cat] = calcularEstatisticas(chamadosCategoria);
    });

    res.json({
      timestamp: new Date().toISOString(),
      por_categoria: analise
    });
  } catch (err) {
    console.error('Erro ao gerar análise por categoria:', err);
    res.status(500).json({ error: 'Erro ao gerar análise' });
  }
});

// GET /api/relatorios/por-tecnico - Performance por técnico
router.get('/por-tecnico', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const chamados = db.chamados;

    const tecnicoStats = {};

    db.usuarios
      .filter(u => u.funcao === 'Técnico de TI')
      .forEach(tecnico => {
        const chamadosTecnico = chamados.filter(c => c.tecnico_id === tecnico.id);
        tecnicoStats[tecnico.nome] = {
          id: tecnico.id,
          email: tecnico.email,
          ...calcularEstatisticas(chamadosTecnico),
          chamados: chamadosTecnico.length
        };
      });

    res.json({
      timestamp: new Date().toISOString(),
      tecnicos: tecnicoStats
    });
  } catch (err) {
    console.error('Erro ao gerar relatório por técnico:', err);
    res.status(500).json({ error: 'Erro ao gerar relatório' });
  }
});

// GET /api/relatorios/satisfacao - Análise de satisfação
router.get('/satisfacao', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    // Dados simulados para satisfação
    res.json({
      nps: 65,
      csat: 4.2,
      taxa_reaberturas: 3.5,
      tempo_medio_resolucao: 6.5,
      chamados_resolvidos_primeira_vez: 78
    });
  } catch (err) {
    console.error('Erro ao gerar relatório de satisfação:', err);
    res.status(500).json({ error: 'Erro ao gerar relatório' });
  }
});

module.exports = router;
