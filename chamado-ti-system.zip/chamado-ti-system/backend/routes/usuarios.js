const express = require('express');
const fs = require('fs');
const path = require('path');
const { verificarToken, verificarEquipeTI } = require('../middleware/auth');
const constants = require('../config/constants');

const router = express.Router();

// Carregar banco de dados
const dbPath = path.join(__dirname, '../data/db.json');
const getDB = () => JSON.parse(fs.readFileSync(dbPath, 'utf8'));
const saveDB = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

// GET /api/usuarios - Listar usuários
router.get('/', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const usuarios = db.usuarios.map(u => ({
      id: u.id,
      nome: u.nome,
      email: u.email,
      funcao: u.funcao,
      departamento: u.departamento,
      telefone: u.telefone,
      ativo: u.ativo,
      data_criacao: u.data_criacao
    }));

    res.json({
      total: usuarios.length,
      usuarios
    });
  } catch (err) {
    console.error('Erro ao listar usuários:', err);
    res.status(500).json({ error: 'Erro ao listar usuários' });
  }
});

// GET /api/usuarios/:id - Obter usuário específico
router.get('/:id', verificarToken, (req, res) => {
  try {
    const db = getDB();
    const usuario = db.usuarios.find(u => u.id === req.params.id);

    if (!usuario) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    // Usuários finais só podem ver seus próprios dados
    if (req.usuario.funcao === 'Usuário Final' && usuario.id !== req.usuario.id) {
      return res.status(403).json({ error: 'Acesso negado' });
    }

    res.json({
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      funcao: usuario.funcao,
      departamento: usuario.departamento,
      telefone: usuario.telefone,
      ativo: usuario.ativo,
      data_criacao: usuario.data_criacao
    });
  } catch (err) {
    console.error('Erro ao obter usuário:', err);
    res.status(500).json({ error: 'Erro ao obter usuário' });
  }
});

// GET /api/usuarios/tecnicos/disponiveis - Listar técnicos disponíveis
router.get('/tecnicos/disponiveis', verificarToken, (req, res) => {
  try {
    const db = getDB();
    const tecnicos = db.usuarios.filter(u => 
      u.funcao === 'Técnico de TI' && u.ativo
    );

    res.json({
      total: tecnicos.length,
      tecnicos: tecnicos.map(t => ({
        id: t.id,
        nome: t.nome,
        email: t.email,
        departamento: t.departamento
      }))
    });
  } catch (err) {
    console.error('Erro ao listar técnicos:', err);
    res.status(500).json({ error: 'Erro ao listar técnicos' });
  }
});

// POST /api/usuarios - Criar novo usuário
router.post('/', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const { nome, email, funcao, departamento, telefone } = req.body;

    if (!nome || !email || !funcao) {
      return res.status(400).json({ 
        error: 'Nome, email e função são obrigatórios' 
      });
    }

    if (!constants.FUNCOES.includes(funcao)) {
      return res.status(400).json({ 
        error: `Função inválida. Valores válidos: ${constants.FUNCOES.join(', ')}` 
      });
    }

    const db = getDB();

    if (db.usuarios.find(u => u.email === email)) {
      return res.status(400).json({ 
        error: 'Usuário com este email já existe' 
      });
    }

    const usuario = {
      id: `USR${Date.now()}`,
      nome,
      email,
      senha: '$2a$10$7PZZmAhQBBFCN9TM3TFgJ.D5D.wE.hXdL4p7hH2GvH6E.7Q5Y1i9m', // 123456 hash
      funcao,
      departamento: departamento || 'Sem departamento',
      telefone: telefone || '',
      ativo: true,
      data_criacao: new Date().toISOString()
    };

    db.usuarios.push(usuario);
    saveDB(db);

    res.status(201).json({
      success: true,
      message: 'Usuário criado com sucesso',
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        funcao: usuario.funcao
      }
    });
  } catch (err) {
    console.error('Erro ao criar usuário:', err);
    res.status(500).json({ error: 'Erro ao criar usuário' });
  }
});

// PUT /api/usuarios/:id - Atualizar usuário
router.put('/:id', verificarToken, verificarEquipeTI, (req, res) => {
  try {
    const db = getDB();
    const usuario = db.usuarios.find(u => u.id === req.params.id);

    if (!usuario) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    const { nome, funcao, departamento, telefone, ativo } = req.body;

    if (nome) usuario.nome = nome;
    if (funcao && constants.FUNCOES.includes(funcao)) usuario.funcao = funcao;
    if (departamento) usuario.departamento = departamento;
    if (telefone) usuario.telefone = telefone;
    if (typeof ativo === 'boolean') usuario.ativo = ativo;

    saveDB(db);

    res.json({
      success: true,
      message: 'Usuário atualizado com sucesso',
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        funcao: usuario.funcao
      }
    });
  } catch (err) {
    console.error('Erro ao atualizar usuário:', err);
    res.status(500).json({ error: 'Erro ao atualizar usuário' });
  }
});

module.exports = router;
