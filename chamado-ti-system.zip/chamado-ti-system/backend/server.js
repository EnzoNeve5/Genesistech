const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const constants = require('./config/constants');

// Importar rotas
const chamadosRoutes = require('./routes/chamados');
const usuariosRoutes = require('./routes/usuarios');
const authRoutes = require('./routes/auth');
const relatoriosRoutes = require('./routes/relatorios');

// Inicializar aplicação
const app = express();

// Middlewares
app.use(cors({
  origin: constants.CORS_ORIGIN,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos do frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Logging middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/chamados', chamadosRoutes);
app.use('/api/usuarios', usuariosRoutes);
app.use('/api/relatorios', relatoriosRoutes);

// Servir frontend para qualquer outra rota
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dashboard.html'));
});

app.get('/novo-chamado', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/novo-chamado.html'));
});

app.get('/meus-chamados', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/meus-chamados.html'));
});

app.get('/gerenciamento', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/gerenciamento.html'));
});

app.get('/relatorios', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/relatorios.html'));
});

// Tratamento de erro 404
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Rota não encontrada',
    path: req.path 
  });
});

// Tratamento de erros global
app.use((err, req, res, next) => {
  console.error('Erro:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Erro interno do servidor',
    status: err.status || 500
  });
});

// Iniciar servidor
const PORT = constants.PORT;
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║   Sistema de Chamados de TI            ║
║   Backend iniciado                     ║
╚════════════════════════════════════════╝

📍 Servidor: http://localhost:${PORT}
📍 API: http://localhost:${PORT}/api
📍 Frontend: http://localhost:3000

Rotas disponíveis:
  - GET  /api/health             (Health check)
  - POST /api/auth/login         (Autenticação)
  - GET  /api/chamados           (Listar chamados)
  - POST /api/chamados           (Criar chamado)
  - GET  /api/chamados/:id       (Detalhes do chamado)
  - GET  /api/relatorios/dashboard (Dashboard)

Ambiente: ${process.env.NODE_ENV || 'desenvolvimento'}
Timestamp: ${new Date().toISOString()}
  `);
});

module.exports = app;
