// Configurações da aplicação
module.exports = {
  // Portas
  PORT: process.env.PORT || 3001,
  FRONTEND_PORT: 3000,

  // JWT
  JWT_SECRET: process.env.JWT_SECRET || 'seu-secret-jwt-super-seguro',
  JWT_EXPIRE: '7d',

  // Categorias de Chamados
  CATEGORIAS: [
    'Hardware',
    'Software',
    'Email',
    'Rede',
    'Impressora',
    'VPN',
    'Sistema Operacional',
    'Banco de Dados',
    'Segurança',
    'Outro'
  ],

  // Subcategorias
  SUBCATEGORIAS: {
    'Hardware': ['Monitor', 'Teclado/Mouse', 'HD', 'Memória', 'Fonte', 'Placa Mãe', 'Outro'],
    'Software': ['Instalação', 'Desinstalação', 'Licença', 'Atualização', 'Erro', 'Outro'],
    'Email': ['Acesso', 'Configuração', 'Sincronização', 'Spam', 'Recuperação', 'Outro'],
    'Rede': ['Conexão', 'WiFi', 'VPN', 'Velocidade', 'DNS', 'Outro'],
    'Impressora': ['Instalação', 'Driver', 'Papel', 'Toner', 'Impressão', 'Outro'],
    'VPN': ['Conexão', 'Configuração', 'Desconexão', 'Velocidade', 'Outro'],
    'Sistema Operacional': ['Windows', 'macOS', 'Linux', 'Atualização', 'Erro', 'Outro'],
    'Banco de Dados': ['Acesso', 'Performance', 'Backup', 'Recuperação', 'Outro']
  },

  // Prioridades
  PRIORIDADES: ['Trivial', 'Baixa', 'Médio', 'Alto', 'Crítico'],

  // Status de Chamado
  STATUS: [
    'Novo',
    'Em Atendimento',
    'Aguardando Usuário',
    'Resolvido',
    'Fechado',
    'Cancelado'
  ],

  // SLA (em horas) por prioridade
  SLA: {
    'Crítico': 1,
    'Alto': 4,
    'Médio': 8,
    'Baixa': 24,
    'Trivial': 48
  },

  // Funções de Usuário
  FUNCOES: ['Usuário Final', 'Técnico de TI', 'Gestor de TI', 'Admin'],

  // Departamentos
  DEPARTAMENTOS: [
    'Financeiro',
    'RH',
    'Vendas',
    'Marketing',
    'Produção',
    'Logística',
    'Administrativo',
    'TI'
  ],

  // Email
  SMTP_CONFIG: {
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: process.env.SMTP_PORT || 587,
    user: process.env.SMTP_USER || 'seu-email@gmail.com',
    pass: process.env.SMTP_PASS || 'sua-senha'
  },

  // Tamanho máximo de arquivo (em bytes)
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB

  // Número máximo de anexos
  MAX_ATTACHMENTS: 5,

  // CORS
  CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:3000'
};
