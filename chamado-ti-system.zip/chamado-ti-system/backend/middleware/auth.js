const jwt = require('jsonwebtoken');
const constants = require('../config/constants');

// Middleware para verificar token JWT
const verificarToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ 
      error: 'Token não fornecido' 
    });
  }

  try {
    const decoded = jwt.verify(token, constants.JWT_SECRET);
    req.usuario = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ 
      error: 'Token inválido ou expirado' 
    });
  }
};

// Middleware para verificar função
const verificarFuncao = (...funcoes) => {
  return (req, res, next) => {
    if (!funcoes.includes(req.usuario.funcao)) {
      return res.status(403).json({ 
        error: 'Acesso negado. Função não autorizada.' 
      });
    }
    next();
  };
};

// Middleware para verificar se é técnico ou gestor
const verificarEquipeTI = (req, res, next) => {
  const equipeTI = ['Técnico de TI', 'Gestor de TI', 'Admin'];
  if (!equipeTI.includes(req.usuario.funcao)) {
    return res.status(403).json({ 
      error: 'Acesso restrito à equipe de TI' 
    });
  }
  next();
};

// Middleware para validação de dados
const validarChamado = (req, res, next) => {
  const { titulo, descricao, categoria, prioridade } = req.body;

  if (!titulo || titulo.trim().length < 3) {
    return res.status(400).json({ 
      error: 'Título deve ter pelo menos 3 caracteres' 
    });
  }

  if (!descricao || descricao.trim().length < 10) {
    return res.status(400).json({ 
      error: 'Descrição deve ter pelo menos 10 caracteres' 
    });
  }

  if (!categoria || !constants.CATEGORIAS.includes(categoria)) {
    return res.status(400).json({ 
      error: `Categoria inválida. Valores válidos: ${constants.CATEGORIAS.join(', ')}` 
    });
  }

  if (!prioridade || !constants.PRIORIDADES.includes(prioridade)) {
    return res.status(400).json({ 
      error: `Prioridade inválida. Valores válidos: ${constants.PRIORIDADES.join(', ')}` 
    });
  }

  next();
};

// Middleware para validação de status
const validarStatus = (req, res, next) => {
  const { status } = req.body;

  if (status && !constants.STATUS.includes(status)) {
    return res.status(400).json({ 
      error: `Status inválido. Valores válidos: ${constants.STATUS.join(', ')}` 
    });
  }

  next();
};

module.exports = {
  verificarToken,
  verificarFuncao,
  verificarEquipeTI,
  validarChamado,
  validarStatus
};
